import PageWrapper from "@/components/PageWrapper";
import React from "react";

const Services = () => {
  return <PageWrapper>Services</PageWrapper>;
};

export default Services;
