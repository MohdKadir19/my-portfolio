export const navLinks = [
  { name: "Home", path: "/" },
  { name: "About", path: "/about" },
  
  { name: "Work", path: "/work" },
  { name: "Contact", path: "/contact" },
];